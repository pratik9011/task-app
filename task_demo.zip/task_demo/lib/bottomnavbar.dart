import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:task_demo/add_product_screen.dart';
import 'package:task_demo/product_search_screen.dart';
import 'package:task_demo/products_screen.dart';
import 'package:task_demo/profile_screen.dart';

import 'bottomCotroller.dart';

class MainWrapper extends StatelessWidget {
  const MainWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    final BottomNavController controller = Get.put(BottomNavController());

    final List<Widget> pages = [
      ProductsScreen(),
      AddProductScreen(),
      ProductSearchScreen(),
      ProfileScreen(),
    ];

    final List<BottomNavigationBarItem> navItems = const [
      BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: 'products'),
      BottomNavigationBarItem(icon: Icon(Icons.add), label: 'Add'),
      BottomNavigationBarItem(icon: Icon(Icons.search), label: 'search'),
      BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
    ];

    return Obx(
      () => Scaffold(
        body: pages[controller.selectedIndex.value],
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: controller.selectedIndex.value,
          onTap: controller.changeTab,
          type: BottomNavigationBarType.fixed,
          // backgroundColor: const Color.fromARGB(255, 217, 241, 198),
          selectedItemColor: Colors.green,
          unselectedItemColor: Colors.grey,
          items: navItems,
        ),
      ),
    );
  }
}
