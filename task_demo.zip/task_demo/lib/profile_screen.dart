// views/profile_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:task_demo/login_screen.dart';
import 'profile_controller.dart';

class ProfileScreen extends StatelessWidget {
  final ProfileController controller = Get.put(ProfileController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("User Profile")),
      body: Obx(() {
        if (controller.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        }

        final user = controller.userData;

        return user.isEmpty
            ? Center(child: Text("No user data"))
            : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundImage: NetworkImage(user['image'] ?? ""),
                  ),
                  SizedBox(height: 20),
                  Text(
                    "Name: ${user['firstName']} ${user['lastName']}",
                    style: TextStyle(fontSize: 18),
                  ),
                  Text(
                    "Email: ${user['email']}",
                    style: TextStyle(fontSize: 16),
                  ),
                  Text(
                    "Username: ${user['username']}",
                    style: TextStyle(fontSize: 16),
                  ),
                  Text(
                    "Gender: ${user['gender']}",
                    style: TextStyle(fontSize: 16),
                  ),
                  InkWell(
                    onTap: () async {
                      final SharedPreferences prefs =
                          await SharedPreferences.getInstance();
                      prefs.clear();
                      Get.offAll(() => LoginScreen());
                    },
                    child: Card(
                      color: Colors.redAccent,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Logout",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
      }),
    );
  }
}
