// views/add_product_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'add_product_controller.dart';

class AddProductScreen extends StatelessWidget {
  final AddProductController controller = Get.put(AddProductController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Product")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: controller.titleController,
              decoration: InputDecoration(labelText: "Title"),
            ),
            TextField(
              controller: controller.descriptionController,
              decoration: InputDecoration(labelText: "Description"),
            ),
            TextField(
              controller: controller.priceController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Price"),
            ),
            TextField(
              controller: controller.categoryController,
              decoration: InputDecoration(labelText: "Category"),
            ),
            const SizedBox(height: 20),
            Obx(() => controller.isLoading.value
                ? CircularProgressIndicator()
                : ElevatedButton(
              onPressed: controller.addProduct,
              child: Text("Add Product"),
            )),
          ],
        ),
      ),
    );
  }
}
