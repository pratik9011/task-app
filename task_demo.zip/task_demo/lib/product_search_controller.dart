// controllers/product_search_controller.dart
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ProductSearchController extends GetxController {
  var isLoading = false.obs;
  var products = [].obs;
  var categories = <String>[].obs;
  var selectedCategory = ''.obs;
  var sortOrder = 'A-Z'.obs;

  final baseUrl = "https://dummyjson.com";

  @override
  void onInit() {
    fetchCategories();
    super.onInit();
  }

  Future<void> fetchCategories() async {
    try {
      final res = await http.get(Uri.parse("$baseUrl/products/categories"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        categories.assignAll(List<String>.from(data));
      }
    } catch (e) {
      Get.snackbar("Error", "Failed to fetch categories");
    }
  }

  Future<void> searchProducts(String query) async {
    if (query.isEmpty) return;

    isLoading(true);
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/products/search?q=$query"),
        headers: {"Content-Type": "application/json"},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        List productList = data['products'];

        sortAndSetProducts(productList);
      } else {
        products.clear();
        Get.snackbar("Error", "Search failed");
      }
    } catch (e) {
      Get.snackbar("Error", e.toString());
    } finally {
      isLoading(false);
    }
  }

  Future<void> filterByCategory(String category) async {
    selectedCategory.value = category;
    isLoading(true);
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/products/category/$category"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        List productList = data['products'];

        sortAndSetProducts(productList);
      } else {
        products.clear();
        Get.snackbar("Error", "Category load failed");
      }
    } catch (e) {
      Get.snackbar("Error", e.toString());
    } finally {
      isLoading(false);
    }
  }

  void sortAndSetProducts(List<dynamic> productList) {
    if (sortOrder.value == 'A-Z') {
      productList.sort(
        (a, b) => a['title'].toString().compareTo(b['title'].toString()),
      );
    } else {
      productList.sort(
        (a, b) => b['title'].toString().compareTo(a['title'].toString()),
      );
    }
    products.assignAll(productList);
  }

  void changeSortOrder(String order) {
    sortOrder.value = order;
    sortAndSetProducts(products);
  }
}
