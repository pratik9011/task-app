// controllers/update_delete_product_controller.dart
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class UpdateDeleteProductController extends GetxController {
  var isLoading = false.obs;
  var product = {}.obs;

  final id = 0.obs;

  final title = ''.obs;
  final description = ''.obs;
  final price = ''.obs;

  Future<void> fetchProduct(int productId) async {
    isLoading(true);
    try {
      final response = await http.get(
        Uri.parse("https://dummyjson.com/products/$productId"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        product.value = data;
        id.value = data['id'];
        title.value = data['title'];
        description.value = data['description'];
        price.value = data['price'].toString();
      } else {
        Get.snackbar("Error", "Product not found");
      }
    } catch (e) {
      Get.snackbar("Error", e.toString());
    } finally {
      isLoading(false);
    }
  }

  Future<void> updateProduct() async {
    isLoading(true);
    try {
      final response = await http.put(
        Uri.parse("https://dummyjson.com/products/${id.value}"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "title": title.value,
          "description": description.value,
          "price": int.tryParse(price.value) ?? 0,
        }),
      );

      if (response.statusCode == 200) {
        Get.snackbar("Success", "Product updated");
      } else {
        Get.snackbar("Failed", "Update failed");
      }
    } catch (e) {
      Get.snackbar("Error", e.toString());
    } finally {
      isLoading(false);
    }
  }

  Future<void> deleteProduct() async {
    isLoading(true);
    try {
      final response = await http.delete(
        Uri.parse("https://dummyjson.com/products/${id.value}"),
      );

      if (response.statusCode == 200) {
        Get.snackbar("Deleted", "Product deleted");
        product.clear();
      } else {
        Get.snackbar("Failed", "Delete failed");
      }
    } catch (e) {
      Get.snackbar("Error", e.toString());
    } finally {
      isLoading(false);
    }
  }
}
