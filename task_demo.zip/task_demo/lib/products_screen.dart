// views/products_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:task_demo/product_detail_screen.dart';
import 'products_controller.dart';

class ProductsScreen extends StatelessWidget {
  final ProductsController controller = Get.put(ProductsController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("All Products")),
      body: Obx(() {
        if (controller.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        }

        if (controller.products.isEmpty) {
          return Center(child: Text("No products found"));
        }

        return RefreshIndicator(
          onRefresh: () async {
            controller.fetchProducts();
          },
          child: ListView.builder(
            itemCount: controller.products.length,
            itemBuilder: (context, index) {
              final product = controller.products[index];
              return ListTile(
                leading: Image.network(
                  product['thumbnail'],
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                ),
                title: Text(product['title']),
                subtitle: Text("Price: \$${product['price']}"),
                onTap: () {
                  Get.to(() => ProductDetailScreen(product: product));
                },
              );
            },
          ),
        );
      }),
    );
  }
}
