// controllers/login_controller.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'bottomnavbar.dart';

class LoginController extends GetxController {
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  var isLoading = false.obs;

  void login() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    isLoading.value = true;
    final response = await http.post(
      Uri.parse("https://dummyjson.com/auth/login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "username": usernameController.text,
        "password": passwordController.text,
      }),
    );

    isLoading.value = false;

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      prefs.setString("accessToken", data["accessToken"]);
      prefs.setString("refreshToken", data["refreshToken"]);
      Get.snackbar("Login Successful", "Welcome ${data['firstName']}!");
      Get.offAll(() => MainWrapper());
    } else {
      Get.snackbar("Login Failed", "Invalid credentials");
    }
  }
}
