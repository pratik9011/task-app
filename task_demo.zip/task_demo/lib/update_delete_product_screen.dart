// views/update_delete_product_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'update_delete_product_controller.dart';

class UpdateDeleteProductScreen extends StatelessWidget {
  final int idController;

  const UpdateDeleteProductScreen({super.key, required this.idController});

  @override
  Widget build(BuildContext context) {
    final UpdateDeleteProductController controller = Get.put(
      UpdateDeleteProductController(),
    );
    controller.fetchProduct(idController);
    return Scaffold(
      appBar: AppBar(title: Text("Update/Delete Product")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Obx(() {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              if (controller.product.isNotEmpty)
                Expanded(
                  child: ListView(
                    children: [
                      TextField(
                        decoration: InputDecoration(labelText: "Title"),
                        onChanged: (val) => controller.title.value = val,
                        controller: TextEditingController(
                          text: controller.title.value,
                        ),
                      ),
                      TextField(
                        decoration: InputDecoration(labelText: "Description"),
                        onChanged: (val) => controller.description.value = val,
                        controller: TextEditingController(
                          text: controller.description.value,
                        ),
                      ),
                      TextField(
                        decoration: InputDecoration(labelText: "Price"),
                        onChanged: (val) => controller.price.value = val,
                        keyboardType: TextInputType.number,
                        controller: TextEditingController(
                          text: controller.price.value,
                        ),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: controller.updateProduct,
                              icon: Icon(Icons.update),
                              label: Text("Update"),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: controller.deleteProduct,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                              ),
                              icon: Icon(Icons.delete),
                              label: Text("Delete"),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              if (controller.isLoading.value)
                const Center(child: CircularProgressIndicator()),
            ],
          );
        }),
      ),
    );
  }
}
