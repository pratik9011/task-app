// views/product_search_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'product_search_controller.dart';
import 'product_detail_screen.dart';

class ProductSearchScreen extends StatelessWidget {
  final ProductSearchController controller = Get.put(ProductSearchController());
  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Search Products")),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: searchController,
                    decoration: InputDecoration(
                      hintText: "Search...",
                      border: OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.search),
                        onPressed:
                            () => controller.searchProducts(
                              searchController.text,
                            ),
                      ),
                    ),
                    onSubmitted: controller.searchProducts,
                  ),
                ),
                const SizedBox(width: 10),
                Obx(
                  () => DropdownButton<String>(
                    value: controller.sortOrder.value,
                    items:
                        ['A-Z', 'Z-A']
                            .map(
                              (e) => DropdownMenuItem<String>(
                                value: e,
                                child: Text(e),
                              ),
                            )
                            .toList(),
                    onChanged: (val) {
                      if (val != null) controller.changeSortOrder(val);
                    },
                  ),
                ),
              ],
            ),
          ),
          Obx(() {
            return controller.categories.isEmpty
                ? Container()
                : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: DropdownButton<String>(
                    hint: Text("Select Category"),
                    value:
                        controller.selectedCategory.value.isNotEmpty
                            ? controller.selectedCategory.value
                            : null,
                    isExpanded: true,
                    items:
                        controller.categories
                            .map(
                              (category) => DropdownMenuItem<String>(
                                value: category,
                                child: Text(category),
                              ),
                            )
                            .toList(),
                    onChanged: (val) {
                      if (val != null) controller.filterByCategory(val);
                    },
                  ),
                );
          }),

          const SizedBox(height: 10),
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }

              if (controller.products.isEmpty) {
                return const Center(child: Text("No products found"));
              }

              return ListView.builder(
                itemCount: controller.products.length,
                itemBuilder: (context, index) {
                  final product = controller.products[index];
                  return ListTile(
                    leading: Image.network(
                      product['thumbnail'],
                      width: 60,
                      height: 60,
                      fit: BoxFit.cover,
                    ),
                    title: Text(product['title']),
                    subtitle: Text("Price: \$${product['price']}"),
                    onTap: () {
                      Get.to(() => ProductDetailScreen(product: product));
                    },
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }
}
